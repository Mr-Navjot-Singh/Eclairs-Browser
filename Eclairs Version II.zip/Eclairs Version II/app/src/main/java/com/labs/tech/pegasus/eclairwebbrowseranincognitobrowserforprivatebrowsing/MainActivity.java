package com.labs.tech.pegasus.eclairwebbrowseranincognitobrowserforprivatebrowsing;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        // Code for Banner Ads

       /* mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        MobileAds.initialize(this, "ca-app-pub-4359516433652859~4108827360");//Banner ad

        // Interstitial ad Code
        MobileAds.initialize(this, "ca-app-pub-4359516433652859~4108827360");//Interstitial ad
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-4359516433652859/6974663850");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());


        //to load a new interstitial after displaying the previous one:
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load the next interstitial.
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });

        mInterstitialAd.setAdListener(new AdListener() {

            @Override
            public void onAdLoaded() {
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }

            }

        });
                */

        //code for app indexing
        Intent intent0 = getIntent();
        String action = intent0.getAction();
        Uri data = intent0.getData();



        {
            final Intent site = new Intent(this, Duck.class);
            findViewById(R.id.searchencrypt).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    site.putExtra("URL", "https://www.searchencrypt.com/");
                    startActivity(site);

                }
            });
            findViewById(R.id.qwant).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    site.putExtra("URL", "https://www.quant.com");
                    startActivity(site);
                }
            });
            findViewById(R.id.duck).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    site.putExtra("URL", "https://www.duckduckgo.com");
                    startActivity(site);
                }
            });
            findViewById(R.id.startpage).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    site.putExtra("URL", "https://www.startpage.com");
                    startActivity(site);
                }
            });
            findViewById(R.id.searx).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    site.putExtra("URL", "https://www.searx.com");
                    startActivity(site);
                }
            });
            findViewById(R.id.gibiru).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    site.putExtra("URL", "https://www.gibiru.com");
                    startActivity(site);
                }
            });
        }




    }
}

